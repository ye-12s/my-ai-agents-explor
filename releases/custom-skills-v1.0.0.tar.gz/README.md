# Custom Skills Collection

Personal collection of AI agent skills for development workflows.

## Contents

### Embedded Development
- **embedded-serial-debugging** - UART/serial debugging techniques
- **jlink-debugging** - J-Link probe usage with SubAgent delegation
- **embedded-logging** - Lightweight logging for microcontrollers
- **embedded-gdb-debugging** - GDB debugging for ARM Cortex-M

### Task Management
- **task-archiving** - Document completed tasks for traceability
  - Optional and mandatory workspace-level archiving
  - Structured archive format with decisions and lessons
- **task-completion-hooks** - Automated post-task actions

### Workflow Optimization
- **parallel-task-decomposition** - Split complex tasks for parallel execution
  - Dependency analysis and scheduling
  - Result integration patterns

### Context Management
- **discussion-context-hook** - Preserve discussion context across subAgents
  - Capture user intent and constraints
  - Pass context to parallel tasks
  - Maintain continuity

## Installation

### Cross-Platform (Recommended)

**Using Python (Linux/macOS/Windows):**
```bash
python install.py

# Options:
python install.py --target ~/.custom/skills    # Custom location
python install.py --force                      # Overwrite existing
python install.py --list                       # List available skills
```

### Linux/macOS

```bash
./install.sh [target_directory] [force]

# Examples:
./install.sh                          # Install to ~/.agents/skills
./install.sh ~/.custom/skills         # Install to custom location
./install.sh ~/.agents/skills true    # Force overwrite existing
```

### Windows

**PowerShell:**
```powershell
.\install.ps1

# Options:
.\install.ps1 -Target C:\Users\Me\CustomSkills   # Custom location
.\install.ps1 -Force                             # Overwrite existing
.\install.ps1 -List                              # List available skills
```

**Command Prompt:**
```cmd
python install.py
```

## Usage

Skills are automatically loaded when tasks match their description.
No manual activation required.

### Quick Reference

```typescript
// Use embedded serial debugging
task({
  load_skills: ["embedded/embedded-serial-debugging"],
  ...
});

// Use task archiving
task({
  load_skills: ["superpowers/task-archiving"],
  ...
});

// Use parallel decomposition
task({
  load_skills: ["superpowers/parallel-task-decomposition"],
  ...
});

// Use discussion context hook
task({
  load_skills: ["superpowers/discussion-context-hook"],
  ...
});
```

## Version History

- v1.0.0 - Initial collection with embedded, archiving, and parallel skills
